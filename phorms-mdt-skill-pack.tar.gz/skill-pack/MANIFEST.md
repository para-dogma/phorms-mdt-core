# 🧠 PhormS-MDT Offline Skill Pack

This pack contains the engineering standards and context for PhormS-MDT.

## Files Included:
- `.ai-instructions.md` - AI personality and rules
- `PROJECT_STATUS.md` - Current project state
- `docs/` - Architecture and documentation
- `scripts/` - Automation tools
- `examples/` - Multi-language setups (if available)

## How to Use:
1. Unpack this folder into a new project.
2. Run `./scripts/validate.sh` to initialize.
3. Feed `.ai-instructions.md` and `PROJECT_STATUS.md` to your AI assistant.
